import Builder from "./components/Builder";

export default function Home() {
  return (
    <Builder/>
  );
}
